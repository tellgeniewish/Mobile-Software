package mobilesoftware.week11.foodrecylerviewtest

import android.app.AlertDialog
import android.content.DialogInterface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import mobilesoftware.week11.foodrecylerviewtest.databinding.ActivityMainBinding
import mobilesoftware.week11.foodrecylerviewtest.databinding.ListItemBinding

class MainActivity : AppCompatActivity() {
    val binding by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        // 데이터 준비
        val foods = FoodDao().foods
        val weathers = WeatherDao().weathers

        // 어댑터 생성
        val adapter = FoodAdapter(foods)
        //val adapter = CustomAdapter(weathers)

        // 레이아웃매니져 생성 및 설정
        val layoutManager = LinearLayoutManager(this)
        layoutManager.orientation = LinearLayoutManager.VERTICAL

        // Recylerview에 레이아웃매니져 및 어댑터 설정
        binding.recylerview.layoutManager = layoutManager
        binding.recylerview.adapter = adapter

        val listener = object: FoodAdapter.OnItemClickListener {
            override fun onItemClick(view: View, position: Int) {
                //TODO("Not yet implemented")
                Toast.makeText(this@MainActivity, "${foods[position]}", Toast.LENGTH_SHORT).show()
                //foods.removeAt(position)
                //adapter.notifyDataSetChanged()
            }
        }
        adapter.setOnItemClickListener(listener)

        val longListener = object: FoodAdapter.OnItemLongClickListener {
            override fun onItemLongClick(view: View, position: Int): Boolean {
                Toast.makeText(this@MainActivity, "${foods[position]} 삭제", Toast.LENGTH_SHORT).show()

                val builder = AlertDialog.Builder(this@MainActivity).apply {
                    setTitle("확인 누르면 삭제됨!!")
                    setMessage("${foods[position]} 삭제하시겠습니까?")
                    setIcon(R.mipmap.ic_launcher_round)
                    setPositiveButton("확인")
                    { p0: DialogInterface?, whichButton: Int
                        -> foods.removeAt(position)
                        adapter.notifyDataSetChanged()
                    }
                    setNegativeButton("취소", null) // null로 하면 눌렀을 때 닫힘
                    setCancelable(false) // 대화상자 주변을 눌렀을 때 true -> 닫힘 / false -> 대화상자 유지
                }
                builder.show()
                Toast.makeText(this@MainActivity, "언제 실행되는지 확인해보세요", Toast.LENGTH_SHORT).show()
                //foods.removeAt(position)
                //adapter.notifyDataSetChanged()
                return true
            }
        }
        adapter.setOnItemLongClickListener(longListener)

        binding.button.setOnClickListener{
            foods.add(FoodDto(R.drawable.food01, "${binding.editText.text}", 10))
            adapter.notifyDataSetChanged()
        }
    }
}