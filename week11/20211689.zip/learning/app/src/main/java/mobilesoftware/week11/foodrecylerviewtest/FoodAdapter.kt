package mobilesoftware.week11.foodrecylerviewtest

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import mobilesoftware.week11.foodrecylerviewtest.databinding.ListItemBinding

class FoodAdapter(val foods: ArrayList<FoodDto>): RecyclerView.Adapter<FoodAdapter.FoodViewHolder>() {

    override fun getItemCount(): Int = foods.size
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {
//        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.list_item, parent, false)
//        return FoodViewHolder(itemView)
        val itemBinding = ListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FoodViewHolder(itemBinding)
    }
    override fun onBindViewHolder(holder: FoodViewHolder, position: Int) {
//        holder.photo.setImageResource(foods[position].photo)
//        holder.food.text = foods[position].food
//        holder.count.text = foods[position].count.toString() // 숫자값을 리소스 연결시키는데 바로 쓰면 안 됨!
        holder.itemBinding.ivPhoto.setImageResource(foods[position].photo)
        holder.itemBinding.tvFood.text = foods[position].food
        holder.itemBinding.tvCount.text = foods[position].count.toString()
    }

    inner class FoodViewHolder(/*view: View*/ val itemBinding: ListItemBinding): RecyclerView.ViewHolder(itemBinding.root) {//{
//        val photo = view.findViewById<ImageView>(R.id.ivPhoto)
//        val food = view.findViewById<TextView>(R.id.tvFood)
//        val count = view.findViewById<TextView>(R.id.tvCount)
//    }
        val TAG = "FoodViewHolder"
        init {
            itemBinding.root.setOnClickListener{
                //val dto : FoodDto = foods[adapterPosition]
                Log.d(TAG, "${foods[adapterPosition]}") // FoodDto의 toString형식으로
                listener.onItemClick(it, adapterPosition)
            }
            itemBinding.root.setOnLongClickListener{
                longListener.onItemLongClick(it, adapterPosition)
                // true // 인터페이스에서 불린값 반환하므로 없어도 됨
            }
        }
    }

    interface OnItemClickListener {
        fun onItemClick(view: View, position: Int): Unit
    }
    lateinit var listener: OnItemClickListener
    fun setOnItemClickListener(listener: OnItemClickListener) { // 리스너를 외부에서 받아서 멤버변수에 저장
        this.listener = listener
    }

    interface OnItemLongClickListener {
        fun onItemLongClick(view: View, position: Int): Boolean
    }
    lateinit var longListener: OnItemLongClickListener
    fun setOnItemLongClickListener(longListener: OnItemLongClickListener) {
        this.longListener = longListener
    }
}