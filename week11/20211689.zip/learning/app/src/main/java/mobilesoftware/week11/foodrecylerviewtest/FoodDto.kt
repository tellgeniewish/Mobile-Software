package mobilesoftware.week11.foodrecylerviewtest

data class FoodDto(val photo: Int, val food: String, var count: Int) { // 리소스 id값이 정수값이라서 photo는 Int
    override fun toString() = "$food ($count)"
//    override fun toString(): String {
//        return "$food ($count)"
//        //return super.toString()
//    }
}